package com.asiainfo1.template;

public class ZzwTemplate {
	private String name;

	public ZzwTemplate(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void test() {
		System.out.println("ZzwTemplate test.");
	}
}
