package com.asiainfo1.template;

public class ZzwTemplate {
	
	public void test() {
		System.out.println("ZzwTemplate test.");
	}
}
