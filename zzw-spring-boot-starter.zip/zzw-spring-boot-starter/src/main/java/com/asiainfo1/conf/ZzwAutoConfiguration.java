package com.asiainfo1.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.asiainfo1.template.ZzwTemplate;

/**
 * 模拟spb的自动装配
 *
 * @author zhangzhiwang
 * @date Jun 30, 2020 3:10:17 PM
 */
@Configuration
public class ZzwAutoConfiguration {// 一般自动配置类的类名都以AutoConfiguration结尾，使人一目了然
	@Bean
	public ZzwTemplate zzwTemplate() {
		return new ZzwTemplate();
	}
}